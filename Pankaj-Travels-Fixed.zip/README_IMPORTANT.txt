Put your images into the images folder:
tata-magic.jpg
car1.jpg
car2.jpg
car3.jpg
